package com.training.rest.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.training.rest.entities.EmployeeRole;
import com.training.rest.exception.EmployeeNotFoundException;
import com.training.rest.repository.EmployeeRoleRepository;
@RestController
@RequestMapping("/api")
public class EmployeeRoleController {
	@Autowired
	private EmployeeRoleRepository repository;
	
	@GetMapping("/employeeroles")
	public List<EmployeeRole> getEmployeeRoles(){
		return repository.findAll();
	}
	
	@GetMapping("/employeeroles/{employeeRoleId}")
	public EmployeeRole getEmployee(@PathVariable Long employeeRoleId) {
		return repository.findById(employeeRoleId)
				.orElseThrow(() -> new EmployeeNotFoundException(employeeRoleId));
	}
	
	@PostMapping("/employeeroles")
	public EmployeeRole addEmployeeRole(@RequestBody EmployeeRole employeeRole) {
		return repository.save(employeeRole);
	}
	
	@PutMapping("/employeeroles/{employeeRoleId}")
	public EmployeeRole modEmployeeRole(@RequestBody EmployeeRole newEmployeeRole,
			@PathVariable Long employeeRoleId) {
		return repository.findById(employeeRoleId)
				.map(employeeRole ->{
					employeeRole.setEmployeeRoleName(newEmployeeRole.getEmployeeRoleName());
					employeeRole.setEmployeeRoleDesc(newEmployeeRole.getEmployeeRoleDesc());
					return repository.save(employeeRole);
				})
				.orElseGet(() ->{
					newEmployeeRole.setEmployeeRoleId(employeeRoleId);
					return repository.save(newEmployeeRole);
				});
	}
	
	@DeleteMapping("/employeeroles/{employeeRoleId}")
	public String delEmployeeRole(@PathVariable Long employeeRoleId) {
		String message=null;
		boolean status=repository.existsById(employeeRoleId);
				
			System.out.print("\nemployee role with employeeRoleId:"+employeeRoleId+" is:"+status);
			if(status) {
				repository.deleteById(employeeRoleId);
				message="EmployeeRole having employeeRoleId:"+employeeRoleId+" has been deleted successfully..";
			}else {
				message="Entered employeeRoleId:"+employeeRoleId+" not found..";
		}
		return message;
	}
}
