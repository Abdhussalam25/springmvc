package com.training.rest.exception;
public class EmployeeNotFoundException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public EmployeeNotFoundException(Long employeeRoleId) {
		super("Could not find employee role having employeeRoleId: "+employeeRoleId);
	}
}
