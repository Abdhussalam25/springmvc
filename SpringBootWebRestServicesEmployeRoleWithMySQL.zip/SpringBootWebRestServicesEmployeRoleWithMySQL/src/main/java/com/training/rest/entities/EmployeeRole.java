package com.training.rest.entities;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="employeerole5")
public class EmployeeRole {
	@Column(name="employeeroleid")
	private @Id @GeneratedValue Long employeeRoleId;
	@Column(name="employeerolename")
	private String employeeRoleName;
	@Column(name="employeeroledesc")
	private String employeeRoleDesc;
	public long getEmployeeRoleId() {
		return employeeRoleId;
	}
	public void setEmployeeRoleId(long employeeRoleId) {
		this.employeeRoleId = employeeRoleId;
	}
	public String getEmployeeRoleName() {
		return employeeRoleName;
	}
	public void setEmployeeRoleName(String employeeRoleName) {
		this.employeeRoleName = employeeRoleName;
	}
	public String getEmployeeRoleDesc() {
		return employeeRoleDesc;
	}
	public void setEmployeeRoleDesc(String employeeRoleDesc) {
		this.employeeRoleDesc = employeeRoleDesc;
	}
	public EmployeeRole() {
		super();
	}
	public EmployeeRole(long employeeRoleId, String employeeRoleName, String employeeRoleDesc) {
		super();
		this.employeeRoleId = employeeRoleId;
		this.employeeRoleName = employeeRoleName;
		this.employeeRoleDesc = employeeRoleDesc;
	}
	
	@Override
	public boolean equals(Object obj) {
		if(this==obj) {
			return true;
		}
		if(!(obj instanceof EmployeeRole)){
			return false;
		}
		
		EmployeeRole role=(EmployeeRole) obj;
		return Objects.equals(this.employeeRoleId,role.employeeRoleId) &&
				Objects.equals(this.employeeRoleName,role.employeeRoleName)&&
				Objects.equals(this.employeeRoleDesc,role.employeeRoleDesc);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(this.employeeRoleId,this.employeeRoleName,this.employeeRoleDesc);
	}
	@Override
	public String toString() {
		return "\n employeeRoleId=" + employeeRoleId + ", employeeRoleName=" + employeeRoleName
				+ ", employeeRoleDesc=" + employeeRoleDesc;
	}
}
