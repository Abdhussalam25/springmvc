package com.training.rest.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.training.rest.entities.EmployeeRole;
public interface EmployeeRoleRepository extends JpaRepository<EmployeeRole,Long>{
}
