package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.training.bean.Country;
import com.training.service.CountryService;

@RestController
public class CountryController {

	@Autowired
	CountryService countryService;
	
//	@GetMapping("/countries")
//	public String init() {
//		
//		return "welcome to money Exchanger";
//		
//	}
	
	@GetMapping("/countries")
	public List<Country> getCounties(){
		List<Country> list = countryService.getAllCountries();
		return list;
	}
	
	@GetMapping("/countries/{id}")
	public Country getCountryById(@PathVariable int id) {
		
		Country country = countryService.getCountryById(id);
		return country;
	}
	
	
	
	
}
